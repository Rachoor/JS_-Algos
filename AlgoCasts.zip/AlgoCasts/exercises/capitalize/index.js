// --- Directions
// Write a function that accepts a string.  The function should
// capitalize the first letter of each word in the string then
// return the capitalized string.
// --- Examples
//   capitalize('a short sentence') --> 'A Short Sentence'
//   capitalize('a lazy fox') --> 'A Lazy Fox'
//   capitalize('look, it is working!') --> 'Look, It Is Working!'



function capitalize(str) {
    newStr= [];
    for (let word of str.split(' ')){
        newStr.push(word[0].toUpperCase()+ word.slice(1));
    }
    return newStr.join(' ');

}

module.exports = capitalize;


// function capitalize(str) {
//     newStr= str.split('');
//     newStr[0]= newStr[0].toUpperCase();
//     for(let i= 0; i <newStr.length; i++){
//         if(newStr[i] === ' '){
//             newStr[i+1] = newStr[i+1].toUpperCase();
//         }
//     }
//
//     return newStr.join('')
// }
