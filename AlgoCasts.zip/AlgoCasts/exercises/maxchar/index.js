// --- Directions
// Given a string, return the character that is most
// commonly used in the string.
// --- Examples
// maxChar("abcccccccd") === "c"
// maxChar("apple 1231111") === "1"

function maxChar(str) {
    count={};
    let max=0;
    let maxChr='';
    for(let char of str){
        // if(count[char]){
        //     count[char] ++;
        // }
        // else{
        //     count[char]=1;
        // }
        count[char]= count[char] ? count[char]+1 : 1
    }
    // for(let key of Object.keys(count)){
    for(let key in count){
        if(count[key]>max){
            max = count[key];
            maxChr = key;
        }

    }
    return maxChr;
}

module.exports = maxChar;
